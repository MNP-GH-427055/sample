
using feebased_service.Models.MenuModel;
using feebased_service.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

//builder.Services.AddTransient<IGetDataRepo,GetDataRepo>();
builder.Services.AddTransient<GetDataRepo>();
builder.Services.AddTransient<PostDataRepo>();
//builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();
builder.Services.AddSession();
builder.Services.AddTransient<DecryptionRepo>();
//builder.Services.AddTransient<GetDataRepo>();
//builder.Services.AddTransient<Util>();
//builder.Services.AddTransient<PostDataRepo>();
//builder.Services.AddTransient<empDto>();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddTransient<feebased_service.Models.MenuModel.EmployeeDetailsModel> ();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}


app.UseSession();

//app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=LoginPage}/{id?}");

app.Run();
