﻿using feebased_service.Models;
using feebased_service.Models.MenuModel;
using feebased_service.Repository;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Configuration;
using System.Diagnostics;
using System.Net;
using System.Xml.Linq;

namespace feebased_service.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;
        private readonly DecryptionRepo _repo;
        private readonly GetDataRepo _Grepo;
        private readonly PostDataRepo _Prepo;
        private readonly string baseurl;
        private readonly string rootfolder;
        
        private readonly IConfiguration _configuration;

        public dynamic details;




        public object Sessions { get; private set; }
        public string MainHeadID = "1";
      

        public HomeController(ILogger<HomeController> logger, DecryptionRepo repo, GetDataRepo grepo, IConfiguration configuration, PostDataRepo prepo)
        {
            _logger = logger;
            _repo = repo;
            _Grepo = grepo;
            _Prepo = prepo;
            _configuration = configuration;
            baseurl = _configuration.GetValue<string>("BasValues:BaseUrl");
            rootfolder = _configuration.GetValue<string>("BasValues:root");
           
            _Prepo = prepo;

            details = _Grepo.attachdata();


        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }



        public IActionResult Dashboard(string id,string token)
        {
            var processid = id;
            var token1 = token;


            if (string.IsNullOrEmpty(processid))
            {
                id = HttpContext.Session.GetString("SessionVal");
                processid = id;

            }

            if (string.IsNullOrEmpty(token1))
            {
                token = HttpContext.Session.GetString("TokenVal");

            }


            HttpContext.Session.SetString("SessionVal", processid);
            HttpContext.Session.SetString("TokenVal", token);

            String[] resession = processid.ToString().Split("¥");    //¥
            id = resession[0];

            var pathBase = "";
            var strHeader = "";
            String[] arrStr;
            String[] arrStrCode;
            string indata = "";
            string ApiPath = "";
        

            if (resession.Length == 1)     // FLUTTER PORTAL 
            {
                //pathBase = session;
                pathBase = WebUtility.UrlDecode(id);
                ApiPath = "PortalSessionApi/api/PortalSession/PortalDecrypt";
                var NewSessionRes = _Prepo.ApiSessionDecript(pathBase, baseurl, ApiPath);
                var newsess = NewSessionRes.Result;

                var parsedData = JsonConvert.DeserializeObject<dynamic>(newsess);
                string strHeader1 = Convert.ToString(parsedData.response);


                //Token Decryption writes here !!!

                token = _repo.FromHexToBase64(token);
                token = _repo.DecryptStringAES(token);

                HttpContext.Session.SetString("TokenValApi", token);




                arrStr = strHeader1.ToString().Split("|");
                arrStrCode = arrStr[2].ToString().Split("!");
                indata = arrStrCode[0];


               
                HttpContext.Session.SetString("BrName", arrStr[1]);
                HttpContext.Session.SetString("UserId", arrStrCode[0]);
                HttpContext.Session.SetString("BrID", arrStr[0]);

            }

            else    //  .NET PORTAL
            {
                pathBase = WebUtility.UrlDecode(id);
                //strHeader = _drepo.Decrypt(pathBase);
                arrStr = strHeader.ToString().Split("|");
                arrStrCode = arrStr[2].ToString().Split("!");
                indata = arrStrCode[0];

            }


           

            ApiPath = "MoneyTransferModernApi/api/Report/GetFeebasedReport/";

            ViewData["baseurl"] = baseurl;
          
            indata = indata + "~" + pathBase;

            string flag = "EMPDTLS";

            ApiPath = baseurl + ApiPath;

            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath, token);

            resData = resData.Replace(@"{""Result"":", @"");
            resData = resData.Replace(@"]}", @"]");
            resData = resData.Replace(@"}]", @"}");
            resData = resData.Replace(@"[{", @"{");

           var parsedData1 = JsonConvert.DeserializeObject<dynamic>(resData);


            var res = parsedData1.RES;

            if (res == "99")
            {

                return RedirectToRoute(new { controller = "Home", action = "closer" });

            }
            else
            {
                
                string bid = Convert.ToString(parsedData1.BRANCH_ID);
                string bname = Convert.ToString(parsedData1.BRANCH_NAME);
                string ename = Convert.ToString(parsedData1.EMP_NAME);
                string accid = Convert.ToString(parsedData1.ACCESS_ID);
                string frmid = Convert.ToString(parsedData1.FIRM_ID);
                string depid = Convert.ToString(parsedData1.DEPARTMENT_ID);
                string designation = Convert.ToString(parsedData1.DESIGNATION);

                ViewData["designation"] = designation;


                HttpContext.Session.SetString("BrID", bid);

                HttpContext.Session.SetString("BrName", bname);

                HttpContext.Session.SetString("EmpName", ename);

                HttpContext.Session.SetString("Accid", accid);

                HttpContext.Session.SetString("Frmid", frmid);

                HttpContext.Session.SetString("Deptid", depid);

                HttpContext.Session.SetString("Designation", designation);


            }


            details = _Grepo.attachdata();

            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;


            return View();
        }




        public IActionResult LoginPage()
        {
            ViewData["baseurl"] = baseurl;
            return View();
        }

        public IActionResult closer(string datas)
        {
            HttpContext.Session.Clear();

            return View();

        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}