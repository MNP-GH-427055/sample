﻿using feebased_service.Models.MenuModel;
using feebased_service.Repository;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore.Identity;
using System.Composition;
using EncryptionLibrary;
using Newtonsoft.Json.Linq;

namespace feebased_service.Controllers
{
    public class DomesticMoneyTransferController : Controller 
    {
        private readonly GetDataRepo _Grepo;
        private readonly PostDataRepo _Prepo;
        private readonly string baseurl;
        private readonly string rootfolder;
        private readonly IConfiguration _configuration;
        public dynamic details;


        public object Session { get; private set; }
        public string MainHeadID = "2";
        public string ResponseData = "";
        public DomesticMoneyTransferController(GetDataRepo grepo, IConfiguration configuration, PostDataRepo prepo)
        {
            _Grepo = grepo;
            _Prepo = prepo;

            details = _Grepo.attachdata();

            _configuration = configuration;
            baseurl = _configuration.GetValue<string>("BasValues:BaseUrl");    
            rootfolder = _configuration.GetValue<string>("BasValues:root");    
        }
        public IActionResult Index(String datas)
        {

            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            details = _Grepo.attachdata();

            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;


            return View(combine);
        }
        public IActionResult Agentonboarding(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            details = _Grepo.attachdata();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }
        [HttpPost]
        [HttpPost]
        public IActionResult DMTSAPICALL([FromBody] AgentRequest obj)
        {
            if (obj == null)
            {
                return Content("Object is null");
            }

            EncryptDecryptService service = new EncryptDecryptService();

            string result = service.createAsyncRequest(obj);

            return Content(result, "application/json");
        }
        [HttpPost]
        public IActionResult ValidateOTP([FromBody] ValidateOtpRequest obj)
        {
            if (obj == null)
            {
                return Content("Object is null");
            }

            EncryptDecryptService service = new EncryptDecryptService();

            string result = service.createAsyncRequest(obj);

            return Content(result, "application/json");
        }
        [HttpPost]
        public IActionResult GetAadharWadh([FromBody] AadhaarWadhRequest obj)
        {
            if (obj == null)
            {
                return Content("Object is null");
            }

            EncryptDecryptService service = new EncryptDecryptService();
            string result = service.createAsyncRequest(obj);

            return Content(result, "application/json");
        }
        public class AgentRequest
        {
            public string requestId { get; set; }
            public string actionName { get; set; }
            public string partnerKey { get; set; }
            public string p1 { get; set; }
            public string p2 { get; set; }
            public string p3 { get; set; }
            public string p4 { get; set; }
            public string p5 { get; set; }
            public string p6 { get; set; }
            public string p7 { get; set; }
            public string p8 { get; set; }
            public string p9 { get; set; }
            public string p10 { get; set; }
            public string p11 { get; set; }
            public string p12 { get; set; }
        }
        public class ValidateOtpRequest
        {
            public string requestId { get; set; }
            public string actionName { get; set; }
            public string partnerKey { get; set; }
            public string p1 { get; set; } // mobile_no
            public string p2 { get; set; } // otpToken
            public string p3 { get; set; } // otp
        }

        public class AadhaarWadhRequest
        {
            public string requestId { get; set; }
            public string actionName { get; set; }
            public string partnerKey { get; set; }
            public string p1 { get; set; } // mobile_no
            public string p2 { get; set; } // kyc_token
            public string p3 { get; set; } // agent_ref_id
        }
    }
}
