﻿using feebased_service.Models.MenuModel;
using feebased_service.Repository;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore.Identity;
using System.Composition;


namespace feebased_service.Controllers
{
    public class MoneyTransferController : Controller
    {
        private readonly GetDataRepo _Grepo;
        private readonly PostDataRepo _Prepo;
        private readonly string baseurl;
        private readonly string rootfolder;
        private readonly IConfiguration _configuration;
        public dynamic details;

                    
        public object Session { get; private set; }
        public string MainHeadID = "1";
        public string ResponseData = "";
        public MoneyTransferController(GetDataRepo grepo, IConfiguration configuration, PostDataRepo prepo) {

            _Grepo = grepo;
            _Prepo = prepo;

            details = _Grepo.attachdata();

            _configuration = configuration;
            baseurl = _configuration.GetValue<string>("BasValues:BaseUrl");    //   uatapp
            rootfolder = _configuration.GetValue<string>("BasValues:root");    //   mebsapp
        }


        //API fetch

        public string getAPIData(string datas)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetFeebasedReport/";

            string[] DataArray = datas.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas;
            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;
            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath,token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }

        public string getCallingcustomerho(string datas)
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetMoneyTransfer/";

            string[] DataArray = datas.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas;
            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;
            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath, token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }

        public string getAPIDataCircular(string datas)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetFeebasedReport/";

            string[] DataArray = datas.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas;
            string flag = DataArray[0];
            string indata = DataArray[1];
            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;
            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath,token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }


        public string getAPIApproval(string datas)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetMaintenace/";

            string[] DataArray = datas.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas;
            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;
            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath,token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }

        //--------------------INWARD ---------------------------

        public string getAPIINWARD(string datas)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetMoneyTransfer/";

            string[] DataArray = datas.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas;
            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;
            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag, ApiPath, token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }


        //Moneytrasfer maintanance
        public string getMTReverseAPIData(string datas1)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetMaintenace/";
            
            string[] DataArray = datas1.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas1;

            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;

            ViewData["user"] = HttpContext.Session.GetString("ecode");
            var empcode = HttpContext.Session.GetString("ecode");
            var empname = HttpContext.Session.GetString("EmpName");
            var branchname = HttpContext.Session.GetString("BrName");
            var UserId = HttpContext.Session.GetString("UserId");
            var brID = HttpContext.Session.GetString("BrID");

            ViewData["BrID"] = brID;
            ViewData["ecode"] = empcode;

            MenuListModel model = new MenuListModel();
            model = (MenuListModel)_Grepo.GetMainMenuData(UserId, baseurl, MainHeadID);


            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag,ApiPath,token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }

        public string getMTReverseAPIData1(string datas2)     //Get API Response
        {
            string ApiPath = "MoneyTransferModernApi/api/Report/GetMaintenace/";
           

            string[] DataArray = datas2.Split('^');

            ViewData["baseurl"] = baseurl;
            ViewData["root"] = rootfolder;
            ViewData["HeadName"] = datas2;

            string token = HttpContext.Session.GetString("TokenValApi");
            ApiPath = baseurl + ApiPath;

            ViewData["user"] = HttpContext.Session.GetString("ecode");
            var empcode = HttpContext.Session.GetString("ecode");
            var empname = HttpContext.Session.GetString("EmpName");
            var branchname = HttpContext.Session.GetString("BrName");
            var UserId = HttpContext.Session.GetString("UserId");
            var brID = HttpContext.Session.GetString("BrID");

            ViewData["BrID"] = brID;
            ViewData["ecode"] = empcode;

            MenuListModel model = new MenuListModel();
            model = (MenuListModel)_Grepo.GetMainMenuData(UserId, baseurl, MainHeadID);

            string flag = DataArray[0];
            string indata = DataArray[1];
            var resData = _Grepo.GetInternalPageData(indata, flag,ApiPath,token);
            // return resData.ToJson();
            resData = resData.Replace(@"{""RESP"":", @"");
            return resData;
        }

       

        // post API DATA


        public async Task<dynamic> postAPIData(string datas2)
        {
            
            string ApiPath = "MoneyTransferModernApi/api/Report/PostMaintenance/";
        
            string[] DataArray = datas2.Split('^');
            string token = HttpContext.Session.GetString("TokenValApi");
            string flag = DataArray[0];
            string indata = DataArray[1];
            var response = await _Prepo.PostInternalPageData(indata, flag, baseurl, ApiPath, token);
            return response.ToString();


        } 




        //loggout 

        [HttpPost]

        public async Task<IActionResult> Logout()
        {
            var s1 = HttpContext.Session;
            s1.Clear();


            // Redirect to an external link
            return Redirect("https://uatapp.manappuram.net/MaaPortal/maaportal/");

        }







        //------------------  views   -------------//



        public IActionResult Index(String datas)
        {
         
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            details = _Grepo.attachdata();

            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;


            return View(combine);
        }





     // -------------  Money TransferReprots----------------//

        //All in one
        public IActionResult AllinoneReport(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            details = _Grepo.attachdata();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }

        // Consolidate REPORT


        public IActionResult ConsolidatedReport(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }


        public IActionResult DrillDown(string datas)

        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }

        public IActionResult RegionDrillDown(String id)
        {
            string[]da = id.Split('~');


            ViewData["fromdate"] = da[0].ToString();
            ViewData["todate"] = da[1].ToString();
            ViewData["zoneid"] = da[2].ToString();
            ViewData["zonename"] = da[3].ToString();

            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }
        public IActionResult DivisionDrillDown(String id)
        {

            string[] da = id.Split('~');


            ViewData["fromdate"] = da[0].ToString();
            ViewData["todate"] = da[1].ToString();
            ViewData["Regionid"] = da[2].ToString();
            ViewData["regionName"] = da[3].ToString();

            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);



        }
        public IActionResult AreaDrillDown(String id)
        {
          
            string[] da = id.Split('~');


            ViewData["fromdate"] = da[0].ToString();
            ViewData["todate"] = da[1].ToString();
            ViewData["divisionid"] = da[2].ToString();
            ViewData["divisionName"] = da[3].ToString();


            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }

        public IActionResult BranchDrillDown(String id)
        {
           
            string[] da = id.Split('~');


            ViewData["fromdate"] = da[0].ToString();
            ViewData["todate"] = da[1].ToString();
            ViewData["areaid"] = da[2].ToString();
            ViewData["areaName"] = da[3].ToString();

            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }
        public IActionResult WesternUnionReport(string datas)
        {

            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }

        public IActionResult PerformanceReport(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }


        //WORKING STATUS PENDING REPORT 
        public IActionResult WorkingStatusPendingReport(string datas)
        {

            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }
        //-------------------end-------------------//

        //---------------Maintanace---------------//

        //REVERESAL

        public IActionResult MtReverse(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);


        }

        //APPROVAL
        public IActionResult MoneyTransferAproval(string datas)

        {

            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
         
        }

        //REPORT
        public IActionResult MtReverseReport(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }

        //-------------------end-------------------//

        //-------------Password Management---------//
        public IActionResult PasswordManagement(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);

        }
        //-------------------end-------------------//

        //--------------circular------------------//

        public IActionResult Circular(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }
        public IActionResult CircularView(string datas, string id)
        {
            //var decodedId = Encoding.UTF8.GetString(Convert.FromBase64String(id.Trim('~')));
            var decodedId = id.Trim('~');
            ViewData["Did"] = decodedId;
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }

        //-------------------end-------------------//


        //---------------MESSAGES AND GUID LINES -------------//
        public IActionResult MessagesToBranches(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }

        public IActionResult InwardTransaction(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }

        public IActionResult GuidlinesToBranches(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }
        public IActionResult Callingcustomerho(string datas)
        {
            string flag = datas;
            MenuListModel model = new MenuListModel();
            CombineModel combine = new CombineModel();
            combine.emp = details;
            model = (MenuListModel)_Grepo.GetMainMenuData(details.EMPCODE, details.BASEURL, MainHeadID);
            combine.menu = model;
            return View(combine);
        }




    }
}
