﻿namespace feebased_service.Models.MenuModel
{
    public class CombineModel
    {

        public MenuListModel menu;

        public EmployeeDetailsModel emp;
    }
}
