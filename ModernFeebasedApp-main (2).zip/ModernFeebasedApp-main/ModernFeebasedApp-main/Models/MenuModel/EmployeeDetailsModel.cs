﻿using System.Reflection;

namespace feebased_service.Models.MenuModel
{
    public class EmployeeDetailsModel
    {

        public string EMPNAME {  get; set; }
        public string EMPCODE { get; set; }
        public string DEPTID { get; set; }
        public string BRNAME { get; set; }
        public string ACCID { get; set; }
        public string BRID { get; set; }
        public string FIRMID { get; set; }
        public string DESIGNATION { get; set; }
        public string ROOTFOLDER { get; set; }
        public string HEADNAME { get; set; }
        public string BASEURL { get; set; }
    }
}
