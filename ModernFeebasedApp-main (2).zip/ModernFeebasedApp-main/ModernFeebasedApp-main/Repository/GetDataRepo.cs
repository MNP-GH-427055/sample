﻿using feebased_service.Models.MenuModel;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;
using System.Web;
using Microsoft.AspNetCore.Mvc;

using NuGet.Protocol.Plugins;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Text;

using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace feebased_service.Repository
{
    public class GetDataRepo
    {

        private IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public GetDataRepo(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        public dynamic GetMainMenuData(string EMPCODE, string baseurl, string MainHeadID)
        {

            MenuListModel menu_ViewModel = new MenuListModel();
            List<MenuNameModel> _mN = new List<MenuNameModel>();
            List<SubMenuNameModel> _sN = new List<SubMenuNameModel>();
            List<ChildMenuNameModel> _cN = new List<ChildMenuNameModel>();
            menu_ViewModel.EmpCode = EMPCODE;

            using (var client = new HttpClient())
            {

                string link = baseurl + "MenuApi/api/MenuApi/GetMenuData/MENUFEEBASEDLOAD/GET_FEEBASED_MAINMENU~";
                client.BaseAddress = new Uri(link + EMPCODE + "*" + MainHeadID + "/1");

                HttpResponseMessage result = client.GetAsync(client.BaseAddress).Result;

                if (result.IsSuccessStatusCode)
                {
                    string data = result.Content.ReadAsStringAsync().Result;
                    data = data.Replace(@"{""menuResDto"":", @"");
                    data = data.Replace(@"{""MenuResDto"":", @"");

                    data = data.Replace(@"}]}", @"}]");
                    data = data.Replace("\"\"", "\"");

                    _mN = JsonConvert.DeserializeObject<List<MenuNameModel>>(data);
                }
                menu_ViewModel.M_NAME = _mN;
                //-----------------------------------------------------------------------------------------------------------------

                using (var sclient = new HttpClient())
                {

                    string slink = baseurl + "MenuApi/api/MenuApi/GetMenuData/MENUFEEBASEDLOAD/GET_FEEBASED_SUBMENU~";
                    sclient.BaseAddress = new Uri(slink + EMPCODE + "/1");

                    HttpResponseMessage sresult = sclient.GetAsync(sclient.BaseAddress).Result;

                    if (sresult.IsSuccessStatusCode)
                    {
                        string sdata = sresult.Content.ReadAsStringAsync().Result;
                        sdata = sdata.Replace(@"{""menuResDto"":", @"");
                        sdata = sdata.Replace(@"{""MenuResDto"":", @"");
                        sdata = sdata.Replace(@"}]}", @"}]");
                        sdata = sdata.Replace("\"\"", "\"");

                        _sN = JsonConvert.DeserializeObject<List<SubMenuNameModel>>(sdata);
                    }
                    menu_ViewModel.S_NAME = _sN;
                    //-----------------------------------------------------------------------------------------------------------------

                    using (var cclient = new HttpClient())
                    {

                        string clink = baseurl + "MenuApi/api/MenuApi/GetMenuData/GETCHILDMENU_MVC1/";
                        cclient.BaseAddress = new Uri(clink + EMPCODE + "/1");

                        HttpResponseMessage cresult = cclient.GetAsync(cclient.BaseAddress).Result;

                        if (cresult.IsSuccessStatusCode)
                        {
                            string cdata = cresult.Content.ReadAsStringAsync().Result;
                            cdata = cdata.Replace(@"{""menuResDto"":", @"");
                            cdata = cdata.Replace(@"{""MenuResDto"":", @"");
                            cdata = cdata.Replace(@"}]}", @"}]");
                            cdata = cdata.Replace("\"\"", "\"");

                            _cN = JsonConvert.DeserializeObject<List<ChildMenuNameModel>>(cdata);
                        }
                        menu_ViewModel.C_NAME = _cN;

                        //-----------------------------------------------------------------------------------------------------------------

                        //  ModelState.Clear();
                        return menu_ViewModel;
                    }
                }
            }
        }

        //public dynamic GetInternalPageData(string indata, string flag, string baseurl, string ApiPath)
        //{

        //    using (var client = new HttpClient())
        //    {
        //        string data = "";

        //        string link = baseurl + ApiPath;
        //        //  string link = baseurl + "smareportsapi/api/SMAModule/GetSMAData/";

        //        client.BaseAddress = new Uri(link + flag + "/" + indata + "/1");

        //        HttpResponseMessage result = client.GetAsync(client.BaseAddress).Result;

        //        if (result.IsSuccessStatusCode)
        //        {
        //            data = result.Content.ReadAsStringAsync().Result;
        //            data = data.Replace(@"{""MenuResDto"":", @"");
        //            //  data = data.Replace(@"}]}", @"}]");
        //            data = data.Replace("\"\"", "");
        //            data = data.Replace("\'", "");

        //        }

        //        //  ModelState.Clear();
        //        return data;
        //    }
        //}

        //public dynamic GetInternalPageData(string indata, string flag, string ApiPath, string token)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        string data = "";
        //        string link = ApiPath + flag + "/" + indata + "/1";

        //        string encodedFlag = HttpUtility.UrlEncode(flag).Replace("+", " ");
        //        string encodedIndata = HttpUtility.UrlEncode(indata).Replace("+", " ");

        //        // Construct full URL safely
        //        string url = $"{ApiPath}{encodedFlag}/{encodedIndata}";


        //        // Create the request
        //        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        //        request.Method = "GET";
        //        request.Headers.Add("Authorization", $"Bearer {token}");


        //        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
        //        using (StreamReader reader = new StreamReader(response.GetResponseStream()))
        //        {
        //            data = reader.ReadToEnd();
        //        }

        //        //  ModelState.Clear();
        //        return data;
        //    }
        //}



        public dynamic GetInternalPageData(string indata, string flag, string ApiPath, string token)
        {
          
            using (var client = new HttpClient())
            {
                string data = "";
                string link = ApiPath + flag + "/" + indata + "/1";

                string encodedFlag = HttpUtility.UrlEncode(flag);
                string encodedIndata = HttpUtility.UrlEncode(indata);

                //// Construct full URL safely
                //string url = $"{ApiPath}{encodedFlag}/{encodedIndata}/1";


                //string encodedFlag = HttpUtility.UrlEncode(flag).Replace("+", " ");
                //string encodedIndata = HttpUtility.UrlEncode(indata).Replace("+", " ");

                // Construct full URL safely
                string url = $"{ApiPath}{encodedFlag}/{encodedIndata}/1";


                // Create the request
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.Headers.Add("Authorization", $"Bearer {token}");


                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    data = reader.ReadToEnd();
                    data = data.Replace(@"{""MenuResDto"":", @"");
                                //  data = data.Replace(@"}]}", @"}]");
                                data = data.Replace("\"\"", "");
                                data = data.Replace("\'", "");
                }


                //  ModelState.Clear();
                return data;
            }
        }

        public dynamic GetInternalPageData2(string indata, string flag, string baseurl, string ApiPath)
        {

            using (var client = new HttpClient())
            {
                string data = "";

                string link = baseurl + ApiPath;
                //  string link = baseurl + "smareportsapi/api/SMAModule/GetSMAData/";

                client.BaseAddress = new Uri(link + flag + "/" + indata + "/1");

                HttpResponseMessage result = client.GetAsync(client.BaseAddress).Result;

                if (result.IsSuccessStatusCode)
                {
                    data = result.Content.ReadAsStringAsync().Result;
                    //data = data.Replace(@"{""MenuResDto"":", @"");
                    ////  data = data.Replace(@"}]}", @"}]");
                    //data = data.Replace("\"\"", "");
                    //data = data.Replace("\'", "");

                }

                //  ModelState.Clear();
                return data;
            }
        }

        public dynamic attachdata()
        {

            var Empcode = _httpContextAccessor.HttpContext.Session.GetString("UserId");
            var Empname = _httpContextAccessor.HttpContext.Session.GetString("EmpName");
            var Branchname = _httpContextAccessor.HttpContext.Session.GetString("BrName");
            var Accid = _httpContextAccessor.HttpContext.Session.GetString("Accid");
            var Brid = _httpContextAccessor.HttpContext.Session.GetString("BrID");
            var Firmid = _httpContextAccessor.HttpContext.Session.GetString("Frmid");
            var Deptid = _httpContextAccessor.HttpContext.Session.GetString("Deptid");
            var DESIGNATION = _httpContextAccessor.HttpContext.Session.GetString("Designation");
            var rootfolder = _configuration.GetValue<string>("BasValues:root");
            var baseurl = _configuration.GetValue<string>("BasValues:BaseUrl");

            var HeadName = "GoldLoans";
            EmployeeDetailsModel model1 = new EmployeeDetailsModel();
            model1.EMPNAME = Empname;
            model1.EMPCODE = Empcode;
            model1.DEPTID = Deptid;
            model1.BRNAME = Branchname;
            model1.ACCID = Accid;
            model1.BRID = Brid;
            model1.FIRMID = Firmid;
            model1.DESIGNATION = DESIGNATION;

            model1.ROOTFOLDER = rootfolder;
            model1.HEADNAME = HeadName;
            model1.BASEURL = baseurl;
            return model1;
        }

    }

}

