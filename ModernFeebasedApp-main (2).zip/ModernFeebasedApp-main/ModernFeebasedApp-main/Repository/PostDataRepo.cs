﻿using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Text;

namespace feebased_service.Repository
{
    public class PostDataRepo
    {

        //public async Task<dynamic> PostInternalPageData(string indata, string flag, string baseurl, string ApiPath)
        //{
        //    string data = "";
        //    using (HttpClient client = new HttpClient())
        //    {

        //        string content = JsonConvert.SerializeObject(new { p_flag = flag, p_pagevalue = indata, p_paravalue = "1" });
        //        var buffer = Encoding.UTF8.GetBytes(content);
        //        var byteContent = new ByteArrayContent(buffer);
        //        byteContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");


        //        string url2 = baseurl + ApiPath;
        //        HttpResponseMessage response2 = await client.PostAsync(url2, byteContent);
        //        if (response2.IsSuccessStatusCode)
        //        {
        //            data = response2.Content.ReadAsStringAsync().Result;
        //            data = data.Replace("\"\"", "");
        //            data = data.Replace("\'", "");
        //            data = data.Replace(@"""RESP"":", @"");

        //        }
        //        else
        //        {
        //            // Handle the failure case
        //            if (response2.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        //            {
        //                data = response2.Content.ReadAsStringAsync().Result;
        //                data = data.Replace("\"\"", "");
        //                data = data.Replace("\'", "");
        //                data = data.Replace(@"""RESP"":", @"");
        //            }
        //            else
        //            {
        //                data = $"Error: {response2.StatusCode} - {response2.ReasonPhrase}";
        //            }
        //        }


        //    }

        //    return data;
        //}

        public async Task<dynamic> PostInternalPageData(string indata, string flag, string baseurl, string ApiPath, string token)
        {
            string data = "";
            using (HttpClient client = new HttpClient())
            {

                string content = JsonConvert.SerializeObject(new { p_pagevalue = indata, p_paravalue = "1", p_flag = flag });
                var buffer = Encoding.UTF8.GetBytes(content);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

                string url2 = baseurl + ApiPath;
                HttpResponseMessage response2 = await client.PostAsync(url2, byteContent);


                if (response2.IsSuccessStatusCode)
                {
                    data = response2.Content.ReadAsStringAsync().Result;

                }

            }

            return data;
        }

        //public async Task<dynamic> PostInternalPageData(string indata, string flag, string baseurl, string ApiPath, string token)
        //{
        //    string data = "";
        //    using (HttpClient client = new HttpClient())
        //    {
        //        // Construct the request payload
        //        var payload = new { p_pagevalue = indata, p_paravalue = "1", p_flag = flag };
        //        string content = JsonConvert.SerializeObject(payload);
        //        var byteContent = new ByteArrayContent(Encoding.UTF8.GetBytes(content));
        //        byteContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

        //        // Add Authorization header
        //        if (!string.IsNullOrEmpty(token))
        //        {
        //            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        //        }
        //        else
        //        {
        //            // Handle missing token appropriately
        //            throw new ArgumentException("Token is null or empty");
        //        }

        //        string url2 = baseurl + ApiPath;

        //        try
        //        {
        //            HttpResponseMessage response2 = await client.PostAsync(url2, byteContent);

        //            if (response2.IsSuccessStatusCode)
        //            {
        //                data = await response2.Content.ReadAsStringAsync();
        //            }
        //            else
        //            {
        //                // Log or handle non-success status codes
        //                var errorContent = await response2.Content.ReadAsStringAsync();
        //                // Log errorContent for debugging
        //                Console.WriteLine($"Error: {response2.StatusCode}, Content: {errorContent}");
        //            }
        //        }
        //        catch (HttpRequestException ex)
        //        {
        //            // Handle network errors
        //            Console.WriteLine($"Request error: {ex.Message}");
        //        }
        //    }

        //    return data;
        //}


        //----------------------------------new session--------------------------

        public async Task<dynamic> ApiSessionDecript(string indata, string baseurl, string ApiPath)
        {
            string data = "";
            using (HttpClient client = new HttpClient())
            {

                string content = JsonConvert.SerializeObject(new {data=indata});
                var buffer = Encoding.UTF8.GetBytes(content);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");


                string url2 = baseurl + ApiPath;
                HttpResponseMessage response2 = await client.PostAsync(url2, byteContent);
                if (response2.IsSuccessStatusCode)
                {
                    data = response2.Content.ReadAsStringAsync().Result;
                    data = data.Replace("\"\"", "");
                    data = data.Replace("\'", "");

                }
                else
                {
                    // Handle the failure case
                    if (response2.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        data = response2.Content.ReadAsStringAsync().Result;
                        data = data.Replace("\"\"", "");
                        data = data.Replace("\'", "");
                    }
                    else
                    {
                        data = $"Error: {response2.StatusCode} - {response2.ReasonPhrase}";
                    }
                }

            }
             
            return data;
        }

    }
}
