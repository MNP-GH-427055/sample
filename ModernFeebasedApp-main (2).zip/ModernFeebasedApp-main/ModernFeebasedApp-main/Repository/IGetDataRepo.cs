﻿namespace feebased_service.Repository
{
    public interface IGetDataRepo
    {
        
    }
}
